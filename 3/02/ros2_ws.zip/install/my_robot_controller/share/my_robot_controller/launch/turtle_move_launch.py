from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='turtlesim',
            executable='turtlesim_node',
            name='sim',
            output='screen'
        ),
        Node(
            package='my_robot_controller',        # 패키지 이름
            executable='turtle_move_control',  # setup.py에 등록한 실행 이름
            name='turtle_control_node',           # 노드 이름 (원하면 생략 가능)
            output='screen'                       # 출력 로그를 터미널에 보여줌
        )
    ])
