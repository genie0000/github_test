from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node

def generate_launch_description():    
    # 로봇 모델 스폰
    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-file', '/home/genie/ros2_ws3/src/my_robot_controller3/my_robot_controller3/urdf/simple_two_wheel_robot.urdf',
            '-entity', 'simple_two_wheel_robot'
        ],
        output='screen'
    )
    
    # circle_drive_node 실행
    circle_drive_node = Node(
        package='my_robot_controller3',
        executable='circle_drive_node',
        output='screen'
    )
    
    return LaunchDescription([
        spawn_entity,
        circle_drive_node
    ])
