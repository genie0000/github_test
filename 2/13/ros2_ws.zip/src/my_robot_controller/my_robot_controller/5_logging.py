import rclpy
from rclpy.node import Node

class LoggingNode(Node):
    def __init__(self):
        super().__init__('logging_node')  # 노드 이름 지정
        self.get_logger().info(f'노드 이름: {self.get_name()}')  # 노드 이름을 로그로 출력

def main(args=None):
    rclpy.init(args=args)               # ROS 2 초기화
    node = LoggingNode()                # 노드 객체 생성
    rclpy.spin(node)                    # 노드를 계속 실행 상태로 유지
    node.destroy_node()                 # 종료 시 노드 삭제
    rclpy.shutdown()                    # ROS 2 종료

if __name__ == '__main__':
    main()
