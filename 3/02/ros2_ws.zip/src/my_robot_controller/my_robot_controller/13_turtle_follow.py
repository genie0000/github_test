import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from turtlesim.srv import Kill, Spawn
from std_srvs.srv import Empty
import random, math

class TurtleFollow(Node):
    def __init__(self):
        super().__init__("turtle_follow")
        self.current_robot = 1
        self.turtle_pose = Pose()
        self.next_location = [0, 0]
        self.spawn_turtle_client = self.create_client(Spawn, "/spawn")
        self.spawn_turtle(2)
        self.cmd_vel_publisher = self.create_publisher(Twist, "/turtle1/cmd_vel", 10)
        self.turtle_pose_subscriber = self.create_subscription(Pose, '/turtle1/pose', self.get_turtle_pose, 10)
        self.pose_msg = Pose()
        self.kill_turtle_client = self.create_client(Kill, "/kill")
        self.quit_service = self.create_service(Empty, "/quit", self.quit_svr_callback)
        self.control_timer = self.create_timer(0.1, self.move_robot)

    def move_robot(self):
        if self.turtle_pose_subscriber == None:
            raise Exception("No turtle pose subscriber")
        next_x = self.next_location[0]
        next_y = self.next_location[1]

        dx = next_x - self.turtle_pose.x
        dy = next_y - self.turtle_pose.y
        distance = math.sqrt(dx ** 2 + dy ** 2)
        if distance < 0.1:
            self.get_logger().info("Robot reached target")
            self.kill_turtle()
            raise Exception("Robot reached target")
        else:
            target_angel = math.atan2(dy, dx)
            angle_diff = target_angel - self.turtle_pose.theta
            if angle_diff > math.pi:
                angle_diff -= 2 * math.pi
            if angle_diff < -math.pi:
                angle_diff += 2 * math.pi

            new_cmd_vel = Twist()
            new_cmd_vel.linear.x = 5 * distance / 14
            if new_cmd_vel.linear.x < 0.5:
                new_cmd_vel.linear.x = 0.5
            if abs(angle_diff) > 0.01:
                new_cmd_vel.angular.z = 1.0 if angle_diff > 0 else -1.0
            else:
                new_cmd_vel.angular.z = 0.0
            self.cmd_vel_publisher.publish(new_cmd_vel)

    def kill_turtle(self, number = 1):
        self.get_logger().info(f"Killing turtle{number}")
        if self.kill_turtle_client.wait_for_service(1):
            kill_request = Kill.Request()
            kill_request.name = f"turtle{number}"
            future = self.kill_turtle_client.call_async(kill_request)
            future.add_done_callback(self.kill_turtle_response)
        else:
            self.get_logger().info("turtlesim's /kill service not available")

    def kill_turtle_response(self, future):
        try:
            future.result()
        except Exception as e:
            self.get_logger().info(f"Service call failed {e}")
        self.get_logger().info("Turtle killed")

    def get_turtle_pose(self, msg):
        self.turtle_pose = msg

    def spawn_turtle(self, robot_number = None):
        if robot_number == None:
            robot_number = self.current_robot + 1

        if self.spawn_turtle_client.wait_for_service(1):
            spawn_request = Spawn.Request()
            spawn_request.x = random.uniform(1.0, 9.0)
            spawn_request.y = random.uniform(1.0, 9.0)
            spawn_request.theta = random.uniform(-math.pi, math.pi)
            spawn_request.name = f"turtle{robot_number}"
            future = self.spawn_turtle_client.call_async(spawn_request)
            future.add_done_callback(self.spawn_turtle_response)
            self.next_location = [spawn_request.x, spawn_request.y]
        else:
            self.get_logger().info("turtlesim's /spawn service not available")

    def spawn_turtle_response(self, future):
        try:
            future.result()
        except Exception as e:
            self.get_logger().info(f"Service call failed {e}")
        self.get_logger().info("Turtle spawned")

    def quit_svr_callback(self, request, response):
        self.kill_turtle(1)
        self.kill_turtle(2)


def main(args=None):
    rclpy.init(args = args)
    turtle_move_control_node = TurtleFollow()
    try:
        rclpy.spin(turtle_move_control_node)
    except Exception as e:
        turtle_move_control_node.get_logger().info(f"Exception in turtle_move_control_node: {e}")
    finally:
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()