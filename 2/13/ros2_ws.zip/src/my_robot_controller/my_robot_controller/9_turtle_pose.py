import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose

class TurtlePoseSubscriber(Node):
    def __init__(self):
        super().__init__('turtle_pose_subscriber')
        # /turtle1/pose 토픽을 구독, 메시지 타입은 Pose
        self.subscription = self.create_subscription(
            Pose,
            '/turtle1/pose',
            self.pose_callback,
            10
        )
        self.last_x = None
        self.last_y = None
        self.last_theta = None

    def pose_callback(self, msg):
        # x, y, theta 값이 이전 값과 다를 때만 출력
        if (msg.x != self.last_x or 
            msg.y != self.last_y or 
            msg.theta != self.last_theta):
            self.get_logger().info(
                f'x: {msg.x:.2f}, y: {msg.y:.2f}, theta: {msg.theta:.2f}'
            )
            self.last_x = msg.x
            self.last_y = msg.y
            self.last_theta = msg.theta

def main(args=None):
    rclpy.init(args=args)
    node = TurtlePoseSubscriber()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
